#include <iostream>
#include <string>
#include <vector>
#include <map>

using namespace std;

struct User {
    string username;
    string password;
    double balance;
    string pin;
    vector<string> transactionHistory;
};

map<string, User> users;

void registerUser() {
    string username, password, pin;
    cout << "Enter a username: ";
    cin >> username;
    cout << "Enter a password: ";
    cin >> password;
    cout << "Set a PIN: ";
    cin >> pin;
    
    User newUser;
    newUser.username = username;
    newUser.password = password;
    newUser.balance = 0.0;
    newUser.pin = pin;
    
    users[username] = newUser;
    
    cout << "Registration successful!\n";
}

bool loginUser(string& currentUser) {
    string username, password;
    cout << "Enter your username: ";
    cin >> username;
    cout << "Enter your password: ";
    cin >> password;
    
    if (users.find(username) != users.end() && users[username].password == password) {
        currentUser = username;
        return true;
    }
    
    return false;
}

void balanceInquiry(const User& user) {

    cout << "Your balance: " << user.balance << endl;
    

}

void moneyTransfer(User& sender) {
    string receiverUsername;
    double amount;
    
    cout << "Enter receiver's username: ";
    cin >> receiverUsername;
    
    if (users.find(receiverUsername) != users.end()) {
        cout << "Enter amount to transfer: ";
        cin >> amount;
        
        if (amount > 0 && amount <= sender.balance) {
            sender.balance -= amount;
            users[receiverUsername].balance += amount;
            
            // Update transaction history
            
            
            cout << "Transfer successful!\n";
        } else {
            cout << "Invalid amount or insufficient balance.\n";
        }
    } else {
        cout << "Receiver's username not found.\n";
    }
}
    



    void receiptOfMoney(User& receiver) {
    string senderUsername;
    double amount;
    
    cout << "Enter sender's username: ";
    cin >> senderUsername;
    
    if (users.find(senderUsername) != users.end()) {
        cout << "Enter received amount: ";
        cin >> amount;
        
        if (amount > 0) {
            receiver.balance += amount;
            
            // Update transaction history
           
            
            cout << "Receipt of money successful!\n";
        } else {
            cout << "Invalid amount.\n";
        }
    } else {
        cout << "Sender's username not found.\n";
    }
}


void airtimePurchase(User& user) {

    double amount;
    
    cout << "Enter airtime amount: ";
    cin >> amount;
    
    if (amount > 0 && amount <= user.balance) {
        user.balance -= amount;
        
        // Update transaction history
        
        cout << "Airtime purchase successful!\n";
    } else {
        cout << "Invalid amount or insufficient balance.\n";
    }

}

void viewTransactionHistory(const User& user) {
    cout << "Transaction History:\n";
    
}


	void changePIN(User& user) {
    string newPIN;
    
    cout << "Enter new PIN: ";
    cin >> newPIN;
    
    user.pin = newPIN;
    
    cout << "PIN changed successfully!\n";
}
    // Implement PIN change logic


int main() {
    string currentUser;
    int choice;
    
    while (true) {
        cout << "1. Register\n2. Login\n3. Balance Inquiry\n4. Money Transfer\n5. Receipt of Money\n6. Airtime Purchase\n7. Transaction History\n8. Change PIN\n9. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        
        switch (choice) {
            case 1:
                registerUser();
                break;
            case 2:
                if (loginUser(currentUser)) {
                    cout << "Login successful!\n";
                } else {
                    cout << "Login failed. Invalid credentials.\n";
                }
                break;
            case 3:
                balanceInquiry(users[currentUser]);
                break;
            case 4:
                moneyTransfer(users[currentUser]);
                break;
            case 5:
                receiptOfMoney(users[currentUser]);
                break;
            case 6:
                airtimePurchase(users[currentUser]);
                break;
            case 7:
                viewTransactionHistory(users[currentUser]);
                break;
            case 8:
                changePIN(users[currentUser]);
                break;
            case 9:
                cout << "Exiting the application.\n";
                return 0;
            default:
                cout << "Invalid choice.\n";
        }
    }
    
    return 0;
}
